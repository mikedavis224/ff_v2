module.exports = {
    CounterData:[
        {
            img:'/assets/images/resume/icon/1.png',
            count:1510,
            desc:'Satisfied Customers'
        },
        {
            img:'/assets/images/resume/icon/2.png',
            count:320,
            desc:'Total Speaker'
        },
        {
            img:'/assets/images/resume/icon/3.png',
            count:45810,
            desc:'Hours Worked'
        },
        {
            img:'/assets/images/resume/icon/4.png',
            count:563,
            desc:'Awwards Winning'
        },
    ]
}
    
