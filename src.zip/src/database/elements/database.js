module.exports = {
    BoxshadowData : [
        {
            class: 'shadow-lg',
            heading:'large shadow'
        },
        {
            class: 'shadow',
            heading:'regular shadow'
        },
        {
            class: 'shadow-sm',
            heading:'small shadow'
        },

    ]
}