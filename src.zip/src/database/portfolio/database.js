module.exports = {
    CenteredSlideData: [
        {
            img: "img1",
            title: "exclusive portfolio",
            date: '2023',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
        },
        {
            img: "img2",
            title: "exclusive portfolio",
            date: '2023',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
        },
        {
            img: "img3",
            title: "exclusive portfolio",
            date: '2023',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
        },
        {
            img: "img4",
            title: "exclusive portfolio",
            date: '2023',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
        },
        {
            img: "img5",
            title: "exclusive portfolio",
            date: '2023',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
        }
    ],

    PortfolioDetail1Data: [
        {
            img: '/assets/images/portfolio/2.jpg',
        },
        {
            img: '/assets/images/portfolio/3.jpg'
        },
        {
            img: '/assets/images/portfolio/5.jpg'
        },
        {
            img: '/assets/images/portfolio/4.jpg'
        },
        {
            img: '/assets/images/portfolio/5.jpg'
        }
    ],

    CreativeWrapperData: [
        {
            img: '../assets/images/portfolio/1.jpg',
            title: 'Lorem Ipsum',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard.'
        },
        {
            img: '../assets/images/portfolio/2.jpg',
            title: 'Lorem Ipsum',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard.'
        },
        {
            img: '../assets/images/portfolio/3.jpg',
            title: 'Lorem Ipsum',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard.'
        },
        {
            img: '../assets/images/portfolio/4.jpg',
            title: 'Lorem Ipsum',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard.'
        },
        {
            img: '../assets/images/portfolio/5.jpg',
            title: 'Lorem Ipsum',
            desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard.'
        },
    ]
}