import React from 'react';
import Portfolio from '../../../../containers/portfolio/basic'

const Section = () => (
    <Portfolio className="col-lg-3 col-sm-6 isotopeSelector" />
)

export default Section;